//
//  FoodClubApp.swift
//  FoodClub
//
//  Created by Ahasun on 1/26/23.
//

import SwiftUI

@main
struct FoodClubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
